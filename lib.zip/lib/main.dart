import 'package:flutter/material.dart';
import './screens/welcome_screen.dart';

main() {
  runApp(const MaterialApp(
    home: WelcomeScreen(),
  ));
}
